# F22-Starter-DB
Simple starter database project for F22 Columbia classes.
