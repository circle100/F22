# F22-Simple-Web-UI
Simple started Angular application for my Columbia Classes, Fall 2022.
