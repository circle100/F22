export class Player {
  playerID: string;
  nameLast: string;
  nameFirst: string;

  constructor(playerID: string, nameLast: string, nameFirst: string) {
    this.playerID = playerID;
    this.nameLast = nameLast;
    this.nameFirst = nameFirst;
  }

}
