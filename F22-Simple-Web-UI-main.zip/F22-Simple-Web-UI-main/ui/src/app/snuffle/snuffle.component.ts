import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snuffle',
  templateUrl: './snuffle.component.html',
  styleUrls: ['./snuffle.component.css']
})
export class SnuffleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
