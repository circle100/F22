import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-columbia-all',
  templateUrl: './columbia-all.component.html',
  styleUrls: ['./columbia-all.component.css']
})
export class ColumbiaAllComponent implements OnInit {

  active = 1;

  constructor() { }

  ngOnInit(): void {
  }

}
